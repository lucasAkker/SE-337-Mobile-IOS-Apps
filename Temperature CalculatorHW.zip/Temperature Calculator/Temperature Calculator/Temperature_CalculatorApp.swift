//
//  Temperature_CalculatorApp.swift
//  Temperature Calculator
//
//  Created by Lucas Vandenakker on 9/15/26.
//

import SwiftUI

@main
struct Temperature_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            TemperatureAppView()
        }
    }
}
