//
//  ContentView.swift
//  Temperature Calculator
//
//  Created by Lucas Vandenakker on 9/15/26.
//

import SwiftUI

struct TemperatureAppView: View {
    
    @State private var temperatureF = "" //@State allows the variable to be changed freely, otherwise it cannot be changed and will cause errors
    
    @State private var temperatureC = ""
    
    enum TemperatureUnits { //Possible types for conversion
        case fahrenheit
        case celcius
    }
    
    //Image changing variable and function
    @State private var currentImage = "4059561-200"
    
    func changeImage(){
        
        if let temp = Double(temperatureC){
            
            if temp < 10{
                currentImage = "coldweather"
            }
            else if temp < 25{
                currentImage = "warmweather"
            }
            else{
                currentImage = "hotweather"
            }
        }
        
    }
    
    func convert(inputTemperature: String, to: TemperatureUnits) -> String{
        
        switch (to){
        case .fahrenheit:
            if let temp = Double(temperatureC){
                let fahrenheit = (temp * 9/5) + 32
                let result = String (format: "%.2f", fahrenheit)
                return result
            }
            
        case .celcius:
            if let temp = Double(temperatureF){ // Creates a temporary variable "temp" which checks if "temperatureF" is a double. If it is a dobule it will continue on to the conversion logic.
                let celcius = (temp - 32) * 5/9
                let result = String(format: "%.2f", celcius)
                return result
            }
        }
        return ""
        
        
    }
        
    
    var body: some View {
        
        VStack { //Vertical Stack (aka top down)
            
            Text("Temperature Conversion!")
                .font(.largeTitle)
                .bold()
            
            
                .padding()
            HStack { //Horizontal Stack (aka left to right)
                //To celcius
                Text("Fahrenheight:")
                TextField("Enter Temperature", text: $temperatureF) //Text field that captures user input and saves it to the variable "temperatureF" (The "$" acts as the pointer to this variable)
                Button("To °C") {
                    temperatureC = convert(inputTemperature: temperatureF, to: .celcius)
                    changeImage()
                }
                .buttonBorderShape(.capsule)
                .buttonStyle(.borderedProminent)
                
            }
            .padding()
            
            
            HStack{
                //To fahrenheit
                Text("Celcius: ")
                TextField("Enter Temperature", text: $temperatureC)
                Button("To °F"){
                    temperatureF = convert(inputTemperature: temperatureC, to: .fahrenheit)
                    changeImage()
                }
                .buttonBorderShape(.capsule)
                .buttonStyle(.borderedProminent)
                
            }
            .padding()
            
            VStack{
                Image(currentImage)
                    .resizable()
                    .scaledToFit()
                    
            }
            
            Spacer() //Fills the rest of screen with space
            
        }
        .padding()
    }
}

#Preview {
    TemperatureAppView()
}
