//
//  Homework2ListViewApp.swift
//  Homework2ListView
//
//  Created by Lucas Vandenakker on 10/1/26.
//

import SwiftUI

@main
struct Homework2ListViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
