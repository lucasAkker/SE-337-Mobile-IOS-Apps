//
//  ContentView.swift
//  Homework2ListView
//
//  Created by Lucas Vandenakker on 10/1/26.
//

import SwiftUI

struct ContentView: View {
    
    @State var resonatorsList = ResonatorViewModel()
    
    var body: some View {
        List(resonatorsList.resonators){
            resonator in ResonatorRowView(resonator: resonator)
        }
    }
}

struct ResonatorRowView: View{
    
    let resonator: Resonator
    
    var body: some View{
        HStack(spacing: 12){
            Image(resonator.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 100, height: 100)
                .clipShape(RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading, spacing: 4){
                Text(resonator.name).font(.headline)
                Text(resonator.type).font(.subheadline)
                Text(resonator.rating).font(.caption)
            }
        }
    }
    
}

#Preview {
    ContentView()
}
