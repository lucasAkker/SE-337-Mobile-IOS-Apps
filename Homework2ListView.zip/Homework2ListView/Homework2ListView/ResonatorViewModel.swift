//
//  ResonatorViewModel.swift
//  Homework2ListView
//
//  Created by Lucas Vandenakker on 10/1/26.
//
import Observation

class ResonatorViewModel {
    
    private var collection = ResonatorCollection()
    
    var resonators: [Resonator] {collection.resonators}
    
}
