//
//  CharacterModel.swift
//  Homework2ListView
//
//  Created by Lucas Vandenakker on 10/1/26.
//
import Foundation

struct Resonator: Identifiable {
    
    //MARK: - properties
    let id = UUID()
    let name: String
    let type: String
    let rating: String
    let imageName: String
    
    
}

struct ResonatorCollection{
    var resonators: [Resonator] = []
    
    //constructor
    
    init(){
        resonators.append(Resonator(name: "Jiyan", type: "Aero", rating: "5 Star", imageName: "jiyan_card"))
        resonators.append(Resonator(name: "Jingran", type: "Fusion", rating: "5 Star", imageName: "jingran_card"))
        resonators.append(Resonator(name: "Qiuyuan", type: "Aero", rating: "5 Star", imageName: "qiu_card"))
        resonators.append(Resonator(name: "Zani", type: "Spectro", rating: "5 Star", imageName: "zani_card"))
        resonators.append(Resonator(name: "Hiyuki", type: "Glacio", rating: "5 Star", imageName: "hiyuki_card"))
    }
}
