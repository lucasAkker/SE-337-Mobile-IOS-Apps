//
//  HomeView.swift
//  NJParks
//
//  Created by RamanLakshmanan on 9/26/25.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        TabView {
            Tab ("Parks", systemImage: "tree") {
                ParksListView()
            }
            Tab ("Map", systemImage: "mappin.and.ellipse") {
                MyMapView()
            }
        }
    }
}

#Preview {
    HomeView()
}
