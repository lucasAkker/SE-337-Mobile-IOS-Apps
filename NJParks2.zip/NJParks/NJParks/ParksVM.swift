//
//  ParksVM.swift
//  parkstest
//
//  Created by RamanLakshmanan on 9/22/25.
//

import Observation

@Observable

class ParksVM {
    let parksModel = ParksModel()
    var njParks: [Park] = []
    
    init () {
        njParks = parksModel.getParks()
    }
    
    func updatePark (park: Park, closed: Bool) {
        if let index = njParks.firstIndex(where: {$0.id == park.id}) {
            njParks[index].closed = closed
            _ = parksModel.updatePark(parkId: index, closed: njParks[index].closed)
        }
    }
    
    
}
