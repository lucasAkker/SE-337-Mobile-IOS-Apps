//
//  ModelStructs.swift
//  NJ Parks
//
//

// structures to match JSON




struct Park: Codable, Identifiable {
    
    let name: String
    let county: String
    let township: String
    let id: Int
    let status: String
    let latitude: Double
    let longitude: Double
    var closed: Bool = false
   
    enum CodingKeys: String, CodingKey {
        case name = "NAME"
        case county = "COUNTY"
        case township = "TOWNSHIP"
        case id = "PARK_ID"
        case status = "STATUS"
        case latitude = "LATITUDE"
        case longitude = "LONGITUDE"
    }
}

