//
//  NJParksModel.swift
//  parkstest
//
//  Created by RamanLakshmanan on 9/22/25.
//

import Foundation

class ParksModel {
    
    private var njParks: [Park] = []
            
    init () {
        readParksData()
    }
    
    func getParks() -> [Park] {
        return self.njParks
    }
    
    
    func getPark(parkId: Int) -> Park? {
        if let park = njParks.first(where: {$0.id == parkId}) {
            return park
        } else {
            return nil
        }
    }
    
    func updatePark(parkId: Int, closed: Bool) -> Bool? {
        if let index = njParks.firstIndex(where: {$0.id == parkId}) {
            njParks[index].closed = closed
            return true
        } else {
            return nil
        }
    }
    
    func readParksData() {
        
        if let filename = Bundle.main.path(forResource: "njparks", ofType: "json") {
            do {
                let jsonStr  = try String (contentsOfFile: filename, encoding: .utf8)
                let jsonData = jsonStr.data(using: .utf8)!
                
                // decode features (top level object)
                njParks = try JSONDecoder().decode([Park].self, from: jsonData)
                print (njParks.count)
                
            }
            // catch { print("The file could not be loaded") }
            catch let DecodingError.keyNotFound(key, context) {
                print("Missing key '\(key.stringValue)' at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
            }
            catch let DecodingError.typeMismatch(type, context) {
                print("Type mismatch: expected \(type) at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
            }
            catch let DecodingError.valueNotFound(type, context) {
                print("Null/missing value: expected \(type) at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
            }
            catch let DecodingError.dataCorrupted(context) {
                print("Data corrupted (invalid JSON?) at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
                if let underlying = context.underlyingError {
                    print("Underlying error: \(underlying)")
                }
            }
            catch let error as CocoaError {
                // File reading problems (file not found, no permission, bad encoding, etc.)
                print("File error: \(error.localizedDescription)")
            }
            catch {
                print("Unexpected error: \(error)")
            }
        }
        else { print ("The file could not be found") }
    }
    
    func codingPathString(_ path: [CodingKey]) -> String {
        path.map { $0.intValue.map { "[\($0)]" } ?? ".\($0.stringValue)" }
            .joined()
    }
}


/* for extensive debugging of JSON
 
 catch let DecodingError.keyNotFound(key, context) {
     print("Missing key '\(key.stringValue)' at path: \(codingPathString(context.codingPath))")
     print("Details: \(context.debugDescription)")
 }
 catch let DecodingError.typeMismatch(type, context) {
     print("Type mismatch: expected \(type) at path: \(codingPathString(context.codingPath))")
     print("Details: \(context.debugDescription)")
 }
 catch let DecodingError.valueNotFound(type, context) {
     print("Null/missing value: expected \(type) at path: \(codingPathString(context.codingPath))")
     print("Details: \(context.debugDescription)")
 }
 catch let DecodingError.dataCorrupted(context) {
     print("Data corrupted (invalid JSON?) at path: \(codingPathString(context.codingPath))")
     print("Details: \(context.debugDescription)")
     if let underlying = context.underlyingError {
         print("Underlying error: \(underlying)")
     }
 }
 catch let error as CocoaError {
     // File reading problems (file not found, no permission, bad encoding, etc.)
     print("File error: \(error.localizedDescription)")
 }
 catch {
     print("Unexpected error: \(error)")
 }

 // Helper to turn the coding path into something readable, e.g. "[0].name"
 func codingPathString(_ path: [CodingKey]) -> String {
     path.map { $0.intValue.map { "[\($0)]" } ?? ".\($0.stringValue)" }
         .joined()
 }
 
 */
