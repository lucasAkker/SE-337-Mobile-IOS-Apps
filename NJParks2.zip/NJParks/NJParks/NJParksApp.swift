//
//  NJParksApp.swift
//  NJParks
//
//  Created by RamanLakshmanan on 9/26/25.
//

import SwiftUI

@main
struct NJParksApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
            
        }
    }
}
