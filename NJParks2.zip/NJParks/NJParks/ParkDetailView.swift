//
//  ParkDetailView.swift
//  NJParks
//
//  Created by RamanLakshmanan on 10/2/26.
//

import SwiftUI
import MapKit

struct ParkDetailView: View {
    
    @State private var locationManager = LocationManager()
    
    let park: Park
    
    var parkInfo: some View {
        let properties = Mirror(reflecting: park).children.compactMap {
            child -> (String, String)? in
            
            guard let name = child.label else {
                return nil
            }
            return (name, String(describing: child.value))
        }
        
        return LazyVGrid(
            columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ],
            alignment: .leading
        ) {
            ForEach(properties, id: \.0) { property in
                Text(property.0)
                    .fontWeight(.semibold)
                Text(property.1)
            }
            
            .padding()
        }
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                ScrollView {
                    parkInfo
                }
                .frame(height: geometry.size.height / 2)
                
                Map(
                    initialPosition: .region(
                        MKCoordinateRegion(
                            center: CLLocationCoordinate2D(latitude: park.latitude, longitude: park.longitude),
                            latitudinalMeters: 400,
                            longitudinalMeters: 400
                        )
                    )
                ) {
                    UserAnnotation()
                    Marker(
                        park.name,
                        coordinate: CLLocationCoordinate2D(latitude: park.latitude, longitude: park.longitude)
                    )
                }
                .mapControls {
                    
                }
                .mapStyle(.hybrid(elevation: .realistic))
                .frame(height: geometry.size.height / 2)
            }
            .navigationTitle(park.name)
        }
    }
}

#Preview {
    let vm = ParksVM()
    let park = vm.njParks[0]
    ParkDetailView(park: park)
}
