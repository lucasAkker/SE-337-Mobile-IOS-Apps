//
//  MyMapView.swift
//  NJParks
//
//  Created by RamanLakshmanan on 9/26/25.
//

import SwiftUI
import MapKit

struct MyMapView: View {
    
    @State private var locationManager = LocationManager()
    
    @State var parksVM = ParksVM()
    @State var selectedPark: Park?
    
    var body: some View {
        Map() {
            UserAnnotation()
            ForEach (parksVM.njParks) { park in
                Annotation(park.township, coordinate: CLLocationCoordinate2D(latitude: park.latitude, longitude: park.longitude)) {
                    Image(systemName: "tree.fill")
                        .foregroundStyle(Color.green)
                        .onTapGesture {
                            selectedPark = park
                        }
                }
            }
        }
        .mapStyle(.standard)
        .sheet(item: $selectedPark) { park in
            ParkDetailView(park: park)
             .presentationDetents([.medium, .large])
             .presentationDragIndicator(.visible)
        }
    }
}

#Preview {
    MyMapView()
}
