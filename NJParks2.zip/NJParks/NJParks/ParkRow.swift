//
//  ParkRow.swift
//  parkstest
//
//  Created by RamanLakshmanan on 9/24/25.
//

import SwiftUI

struct ParkRow: View {
    let park: Park
    var body: some View {
        VStack(alignment: .leading) {
            Text(park.name)
                .font(.headline)
            HStack {
                Text(park.township)
                Spacer()
                Text(park.county)
            }
            HStack {
                Text(park.status)
                Spacer()
                if park.closed  {
                    Text ("CLOSED")
                        .foregroundColor(.white)                        
                        .background(Color.red)
                }
            }
           
        }
        .padding()
    }
}

