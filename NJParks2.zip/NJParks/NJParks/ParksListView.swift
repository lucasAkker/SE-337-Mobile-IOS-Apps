//
//  ContentView.swift
//  parkstest
//
//  Created by RamanLakshmanan on 9/22/25.
//

import SwiftUI

struct ParksListView: View {
    
    @State var parksVM = ParksVM()
    @State var searchText: String = ""
    
    var body: some View {
        NavigationStack {
            List (searchResults) {park in
                NavigationLink(destination: ParkDetailView(park: park)) {
                    ParkRow(park: park)
                }
                
            }
            .navigationTitle("Parks")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText)
        }
        
    }
    
    var searchResults: [Park] {
        if searchText.isEmpty {
            return parksVM.njParks
        } else {
            return parksVM.njParks.filter {searchFilter(park: $0)}
        }
    }
    
    func searchFilter (park: Park) -> Bool {
        return park.name.lowercased().contains(searchText.lowercased())
        || park.township.lowercased().contains(searchText.lowercased())
        || park.county.lowercased().contains(searchText.lowercased())
        || park.status.lowercased().contains(searchText.lowercased())
    }
}

#Preview {
    ParksListView()
}
