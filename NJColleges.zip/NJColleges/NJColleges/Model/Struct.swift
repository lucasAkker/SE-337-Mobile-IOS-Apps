//
//  Struct.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/13/26.
//
import Foundation
import CoreLocation

struct College: Decodable, Identifiable {
    
    let id: Int
    let geometry: Geometry
    let properties: Properties
}
    
struct Geometry: Decodable {
    let type: String
    let coordinates: [Double]
    
    var longitude: Double { coordinates[0] }
    var latitude: Double  { coordinates[1] }
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}
    
struct Properties: Decodable {
    let fid: Int
    let objectId: Int
    let name: String
    let municipality: String
    let county: String
    let parcel: String
    let comments: String
    let naicsDescription: String
    let gnis: String
    let naicsCode: String
    let munCode: String
    let areaCode: String
    let phone: String
    let address: String
    let address2: String
    let city: String
    let state: String
    let zip: String
    let zip4: String
    let fips: String
    let degree: String
    let enrollment: String
    let shapeLength: Double
    let shapeArea: Double
    let doctoral: String
    let publicResearch: String
    let origFid: Int
    
    enum CodingKeys: String, CodingKey {
        case fid = "FID"
        case objectId = "OBJECTID"
        case name = "Name"
        case municipality = "Municipali"
        case county = "County"
        case parcel = "Parcel"
        case comments = "Comments"
        case naicsDescription = "NAICSDESCR"
        case gnis = "GNIS"
        case naicsCode = "NAICSCODE"
        case munCode = "MUN_CODE"
        case areaCode = "AREA_CODE"
        case phone = "PHONE"
        case address = "ADDRESS"
        case address2 = "ADDRESS2"
        case city = "CITY"
        case state = "STATE"
        case zip = "ZIP"
        case zip4 = "ZIP4"
        case fips = "FIPS"
        case degree = "DEGREE"
        case enrollment = "ENROLLMENT"
        case shapeLength = "Shape_Leng"
        case shapeArea = "Shape_Area"
        case doctoral = "DOCTORAL"
        case publicResearch = "PUBLIC_RES"
        case origFid = "ORIG_FID"
    }
}
