//
//  Struct.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/13/26.
//

struct College: Codable, Identifiable {
    
    let id: Int
    let name: String
    let address: String
    
    enum CodingKeys: String, CodingKey {
        
        case id = "FID"
        case name = "Name"
        case address = "ADDRESS"
        
    }
}
