//
//  CollegeModel.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/13/26.
//

import Foundation

class CollegeModel {
    
    private var njcolleges: [College] = []
    
    init () {
        readCollegeData()
    }
    
    func getColleges() -> [College]{
        return self.njcolleges
    }
    
    func getCollege(collegeId: Int) -> College? {
        if let college = njcolleges.first(where: {$0.id == collegeId}){
            return college
        }
        else{
            return nil
        }
    }
    

    
    
    //function for reading the json file
    func readCollegeData (){
        
        if let filename = Bundle.main.path(forResource: "NJColleges", ofType: "json"){
            do{
                
                let jsonStr = try String (contentsOfFile: filename, encoding: .utf8)
                let jsonData = jsonStr.data(using: .utf8)!
                
                //decode feautrs (top lvl object)
                njcolleges = try JSONDecoder().decode([College].self, from: jsonData)
                print(njcolleges.count)
            }
            
            // catch { print("The file could not be loaded") }
            catch let DecodingError.keyNotFound(key, context) {
                print("Missing key '\(key.stringValue)' at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
            }
            catch let DecodingError.typeMismatch(type, context) {
                print("Type mismatch: expected \(type) at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
            }
            catch let DecodingError.valueNotFound(type, context) {
                print("Null/missing value: expected \(type) at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
            }
            catch let DecodingError.dataCorrupted(context) {
                print("Data corrupted (invalid JSON?) at path: \(codingPathString(context.codingPath))")
                print("Details: \(context.debugDescription)")
                if let underlying = context.underlyingError {
                    print("Underlying error: \(underlying)")
                }
            }
            catch let error as CocoaError {
                // File reading problems (file not found, no permission, bad encoding, etc.)
                print("File error: \(error.localizedDescription)")
            }
            catch {
                print("Unexpected error: \(error)")
            }
            
        }
        
        else { print ("The file could not be found") }
        
    }
    
    func codingPathString(_ path: [CodingKey]) -> String {
        path.map { $0.intValue.map { "[\($0)]"} ?? ".\($0.stringValue)"}.joined()
    }
}

