//
//  NJCollegesApp.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/13/26.
//

import SwiftUI

@main
struct NJCollegesApp: App {
    init(){
        let model = CollegeModel()
        print("Loaded:", model.getColleges().count)
        print("First:", model.getColleges().first as Any)
        print("Lookup:", model.getCollege(collegeId: 1) as Any)
    }
    
    var body: some Scene {
        WindowGroup { Text("testing") }
    }
}
