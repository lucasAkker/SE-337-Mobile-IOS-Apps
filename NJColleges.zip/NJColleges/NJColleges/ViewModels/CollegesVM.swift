//
//  CollegesVM.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import Foundation
import Observation
import MapKit

@Observable
class CollegesVM {

    private let collegeModel = CollegeModel()
    var colleges: [College] = []

    private let northBoundary = 40.47368
    private let southBoundary = 39.95219

    init() {
        colleges = collegeModel.getColleges()
            .sorted { $0.properties.name < $1.properties.name }
    }

    // MARK: - Summary View

    var totalCount: Int {
        colleges.count
    }

    var northCount: Int {
        colleges.filter { $0.geometry.latitude > northBoundary }.count
    }

    var centralCount: Int {
        colleges.filter {
            $0.geometry.latitude >= southBoundary && $0.geometry.latitude <= northBoundary
        }.count
    }

    var southCount: Int {
        colleges.filter { $0.geometry.latitude < southBoundary }.count
    }

    // MARK: - List View

    func search(_ text: String) -> [College] {
        guard !text.isEmpty else { return colleges }
        return colleges.filter {
            $0.properties.name.localizedCaseInsensitiveContains(text)
            || $0.properties.city.localizedCaseInsensitiveContains(text)
            || $0.properties.county.localizedCaseInsensitiveContains(text)
        }
    }

    // MARK: - Map View

    let njRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.10, longitude: -74.60),
        span: MKCoordinateSpan(latitudeDelta: 2.9, longitudeDelta: 2.3)
    )
}
