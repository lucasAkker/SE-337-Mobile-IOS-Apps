//
//  CollegeRowView.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import SwiftUI
import UIKit

struct CollegeRow: View {
    let college: College

    var body: some View {
        HStack(spacing: 12) {
            CollegeLogo(college: college, size: 44)
            VStack(alignment: .leading, spacing: 2) {
                Text(college.properties.name)
                    .font(.headline)
                Text(college.properties.address.capitalized)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text("\(college.properties.city.capitalized), \(college.properties.state) \(college.properties.zip)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// Uses an image named "logo_<FID>" from Assets if it exists
// (e.g. "logo_30" for Ramapo), otherwise a generic college icon.
struct CollegeLogo: View {
    let college: College
    var size: CGFloat = 44

    private var logo: UIImage? {
        UIImage(named: "logo_\(college.properties.fid)")
    }

    var body: some View {
        ZStack {
            if let logo {
                RoundedRectangle(cornerRadius: size * 0.22)
                    .fill(Color.white)
                Image(uiImage: logo)
                    .resizable()
                    .scaledToFit()
                    .padding(size * 0.08)
            } else {
                RoundedRectangle(cornerRadius: size * 0.22)
                    .fill(Color.indigo.gradient)
                Image(systemName: "building.columns.fill")
                    .font(.system(size: size * 0.45))
                    .foregroundStyle(.white)
            }
        }
        .frame(width: size, height: size)
    }
}
