//
//  CollegeDetailView.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import SwiftUI
import MapKit

struct CollegeDetailView: View {

    let college: College

    private var p: Properties { college.properties }

    private var fullAddress: String {
        "\(p.address.capitalized)\n\(p.city.capitalized), \(p.state) \(p.zip)"
    }

    private var enrollmentText: String {
        Int(p.enrollment).map { $0.formatted() } ?? p.enrollment
    }

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {

                // (top half / info)
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 12) {
                            CollegeLogo(college: college, size: 60)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(p.name)
                                    .font(.title3.bold())
                                Text("\(p.municipality), \(p.county) County")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        Divider()

                        InfoRow(label: "Address", value: fullAddress)
                        InfoRow(label: "Phone", value: "(\(p.areaCode)) \(p.phone)")
                        InfoRow(label: "Enrollment", value: enrollmentText)
                        InfoRow(label: "Highest Degree", value: p.degree)
                        InfoRow(label: "Doctoral", value: p.doctoral)
                        InfoRow(label: "Public Research", value: p.publicResearch)
                    }
                    .padding()
                }
                .frame(height: geometry.size.height / 2)

                // (bottom half of mAp)
                Map(initialPosition: .region(
                    MKCoordinateRegion(center: college.geometry.coordinate,
                                       latitudinalMeters: 800,
                                       longitudinalMeters: 800)
                )) {
                    UserAnnotation()
                    Marker(p.name,
                           systemImage: "building.columns.fill",
                           coordinate: college.geometry.coordinate)
                        .tint(.indigo)
                }
                .mapStyle(.hybrid(elevation: .realistic))
                .frame(height: geometry.size.height / 2)
            }
        }
        .navigationTitle(p.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct InfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top) {
            Text(label)
                .fontWeight(.semibold)
                .frame(width: 130, alignment: .leading)
            Text(value)
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
        }
    }
}

#Preview {
    let vm = CollegesVM()
    NavigationStack {
        CollegeDetailView(college: vm.colleges[0])
    }
}
