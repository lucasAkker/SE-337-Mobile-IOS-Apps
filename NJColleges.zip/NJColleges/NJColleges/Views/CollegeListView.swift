//
//  CollegeListView.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import SwiftUI

struct CollegeListView: View {

    @Environment(CollegesVM.self) private var collegesVM
    @State private var searchText = ""

    var body: some View {
        NavigationStack {
            List(collegesVM.search(searchText)) { college in
                NavigationLink(destination: CollegeDetailView(college: college)) {
                    CollegeRow(college: college)
                }
            }
            .navigationTitle("Colleges")
            .searchable(text: $searchText, prompt: "Name, city or county")
        }
    }
}

#Preview {
    CollegeListView()
        .environment(CollegesVM())
}
