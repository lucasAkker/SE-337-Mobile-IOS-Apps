//
//  HomeView.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import SwiftUI

struct HomeView: View {

    @State private var collegesVM = CollegesVM()

    var body: some View {
        TabView {
            Tab("Summary", systemImage: "chart.bar.fill") {
                SummaryView()
            }
            Tab("Colleges", systemImage: "list.bullet") {
                CollegeListView()
            }
            Tab("Map", systemImage: "map.fill") {
                CollegeMapView()
            }
        }
        .environment(collegesVM)
    }
}

#Preview {
    HomeView()
}
