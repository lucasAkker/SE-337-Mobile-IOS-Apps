//
//  SummaryView.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import SwiftUI

struct SummaryView: View {

    @Environment(CollegesVM.self) private var collegesVM

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    VStack(spacing: 4) {
                        Image(systemName: "graduationcap.fill")
                            .font(.largeTitle)
                            .foregroundStyle(.indigo)
                        Text("\(collegesVM.totalCount)")
                            .font(.system(size: 64, weight: .bold, design: .rounded))
                        Text("Total Colleges")
                            .font(.headline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 24)
                    .background(Color.indigo.opacity(0.1),
                                in: RoundedRectangle(cornerRadius: 20))

                    RegionCard(title: "North Jersey Colleges",
                               subtitle: "Above 40.47368° N",
                               icon: "arrow.up",
                               color: .blue,
                               count: collegesVM.northCount,
                               total: collegesVM.totalCount)

                    RegionCard(title: "Central Jersey Colleges",
                               subtitle: "39.95219° – 40.47368° N",
                               icon: "equal",
                               color: .green,
                               count: collegesVM.centralCount,
                               total: collegesVM.totalCount)

                    RegionCard(title: "South Jersey Colleges",
                               subtitle: "Below 39.95219° N",
                               icon: "arrow.down",
                               color: .orange,
                               count: collegesVM.southCount,
                               total: collegesVM.totalCount)
                }
                .padding()
            }
            .navigationTitle("NJ Colleges")
        }
    }
}

struct RegionCard: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    let count: Int
    let total: Int

    private var fraction: Double {
        total == 0 ? 0 : Double(count) / Double(total)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(.white)
                    .frame(width: 32, height: 32)
                    .background(color, in: Circle())
                VStack(alignment: .leading) {
                    Text(title).font(.headline)
                    Text(subtitle).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Text("\(count)")
                    .font(.title.bold())
                    .monospacedDigit()
            }
            ProgressView(value: fraction)
                .tint(color)
            Text("\(Int((fraction * 100).rounded()))% of all colleges")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemBackground),
                    in: RoundedRectangle(cornerRadius: 16))
    }
}

#Preview {
    SummaryView()
        .environment(CollegesVM())
}
