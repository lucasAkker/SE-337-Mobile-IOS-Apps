//
//  CollegeMapView.swift
//  NJColleges
//
//  Created by Lucas Vandenakker on 10/16/26.
//
import SwiftUI
import MapKit

struct CollegeMapView: View {

    @Environment(CollegesVM.self) private var collegesVM
    @State private var locationManager = LocationManager()
    @State private var selectedCollege: College?

    var body: some View {
        Map(initialPosition: .region(collegesVM.njRegion)) {
            UserAnnotation()

            ForEach(collegesVM.colleges) { college in
                Annotation(college.properties.name,
                           coordinate: college.geometry.coordinate) {
                    Image(systemName: "building.columns.fill")
                        .font(.caption)
                        .foregroundStyle(.white)
                        .padding(6)
                        .background(Color.indigo, in: Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 1.5))
                        .onTapGesture {
                            selectedCollege = college
                        }
                }
            }
        }
        .mapStyle(.standard)
        .mapControls {
            MapUserLocationButton()
            MapCompass()
            MapScaleView()
        }
        .sheet(item: $selectedCollege) { college in
            NavigationStack {
                CollegeDetailView(college: college)
            }
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
    }
}

#Preview {
    CollegeMapView()
        .environment(CollegesVM())
}
